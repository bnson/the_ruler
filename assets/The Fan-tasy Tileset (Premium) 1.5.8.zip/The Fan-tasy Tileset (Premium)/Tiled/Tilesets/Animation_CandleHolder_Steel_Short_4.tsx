<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Animation_CandleHolder_Steel_Short_4" tilewidth="16" tileheight="16" tilecount="12" columns="4">
 <image source="../../Art/Props/Animations/Animation_CandleHolder_Steel_Short_4.png" width="64" height="48"/>
 <tile id="0">
  <animation>
   <frame tileid="0" duration="150"/>
   <frame tileid="1" duration="150"/>
   <frame tileid="2" duration="150"/>
   <frame tileid="3" duration="150"/>
  </animation>
 </tile>
 <tile id="4">
  <animation>
   <frame tileid="4" duration="150"/>
   <frame tileid="5" duration="150"/>
   <frame tileid="6" duration="150"/>
   <frame tileid="7" duration="150"/>
  </animation>
 </tile>
</tileset>
